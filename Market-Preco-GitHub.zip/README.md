# Market Preço

Site estático para simular taxas e custos de envio da Shopee e do Mercado Livre.

## Arquivos

- `index.html`: aplicação completa em HTML, CSS e JavaScript.
- Não exige instalação de dependências nem etapa de build.

## Importar para o GitHub

1. Crie um repositório no GitHub, por exemplo `market-preco`.
2. Extraia este ZIP e envie os arquivos da pasta para a raiz do repositório.
3. Para enviar pelo Git, execute na pasta extraída:

```bash
git init
git add .
git commit -m "Adicionar Market Preço"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/market-preco.git
git push -u origin main
```

Troque `SEU-USUARIO` pelo seu nome de usuário ou organização no GitHub.

## Publicar com GitHub Pages (opcional)

Depois de enviar os arquivos, ative o GitHub Pages nas configurações do repositório e selecione a branch `main` e a pasta raiz (`/`). O `index.html` já está na raiz para servir como página inicial.
